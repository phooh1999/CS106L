/**
 * 文件: hashmap_impl.h
 * ---------------------
 * HashMap 实现部分
 */

#pragma once

#include <iomanip>  // for setw, setprecision, setfill, right
#include <sstream>  // for istringstream
#include "hashmap.h"

/*
 * Notes: in the member initializer list (see the next function for an
 * explanation), we call another constructor. This is called a delegating constructor.
 * We simply call the second constructor below with default parameters.
 *
 * Notes: here we use a delegating constructor. Here, we simply
 * call the second constructor below, passing in a default bucket_count of 10.
 */
template <typename K, typename M, typename H>
HashMap<K, M, H>::HashMap() : HashMap{kDefaultBuckets} {
}

/*
 * Notes: here we use a member initializer list to construct each of
 * our members. Recall that a member initializer list is superior to
 * assigning each member. Member initializer lists directly construct
 * a member, while assigning results in a default construction of a member
 * followed by reassignment. In fact, some types (references, uncopyable types)
 * cannot be reassigned, so member initializer lists are necessary. The type of
 * H here is likely a lambda function, which you've seen is non-copyable, so
 * the code won't compile if you use direct assignment.
 */
template <typename K, typename M, typename H>
HashMap<K, M, H>::HashMap(size_t bucket_count, const H& hash)
    : _size{0}, _hash_function{hash}, _buckets_array{bucket_count, nullptr} {
}

/*
 * Notes: The clear() call frees all the nodes. When the destructor
 * calls free, it will later free the memory for the vector, so we
 * don't have to worry about that here.
 */
template <typename K, typename M, typename H>
HashMap<K, M, H>::~HashMap() {
    clear();
}

/*
 * Notes: what is inline? inline is a non-binding directive to the
 * compiler to prefer inline substitution (copy the body of the function
 * to the location of the function call), rather than actually make
 * a function call. This is faster, particularly if the code is very short.
 */
template <typename K, typename M, typename H>
inline size_t HashMap<K, M, H>::size() const noexcept {
    return _size;
}

/*
 * Notes: prefer calling external member functions (size()) rather than
 * calling private functions or members whenever possible. This ensures
 * self-consistency between empty() and size().
 */
template <typename K, typename M, typename H>
inline bool HashMap<K, M, H>::empty() const noexcept {
    return size() == 0;
}

template <typename K, typename M, typename H>
inline float HashMap<K, M, H>::load_factor() const noexcept {
    return static_cast<float>(size()) / bucket_count();
};

template <typename K, typename M, typename H>
inline size_t HashMap<K, M, H>::bucket_count() const noexcept {
    return _buckets_array.size();
};

template <typename K, typename M, typename H>
bool HashMap<K, M, H>::contains(const K& key) const noexcept {
    return find_node(key).second != nullptr;
}

/*
 * Implementation details: loops through each bucket,
 * and repeatedly deletes curr and sets curr to the next node.
 * At the end curr (reference to the pointer living inside the vector)
 * will be nullptr.
 *
 * HashMap is still valid after clear and can be reused, because
 * the vector is still full of nullptrs.
 */
template <typename K, typename M, typename H>
void HashMap<K, M, H>::clear() noexcept {
    for (auto& curr : _buckets_array) {
        while (curr != nullptr) {
            auto trash = curr;
            curr = curr->next;
            delete trash;
        }
    }
    _size = 0;
}

/**
 * 此处返回类型包含指针，编译器无法判断其类型。
 * 所以，需要结合限定名和模板，并使用 typename 声明。
 * - “限定名”就是在 :: 运算符左边的名字
 * - 模板提供类型定义
 */
template <typename K, typename M, typename H>
std::pair<typename HashMap<K, M, H>::value_type*, bool> HashMap<K, M, H>::insert(
    const value_type& value) {
    const auto& [key, mapped] = value;           // 使用引用，避免数据拷贝
    auto [prev, node_to_edit] = find_node(key);  // 无需引用，指针拷贝影响不大

    // 如果元素存在，则无需操作，直接返回找到的当前元素
    if (node_to_edit != nullptr)
        return {&(node_to_edit->value), false};

    // 哈希值取模，以确定桶数组的索引
    size_t index = _hash_function(key) % bucket_count();

    // 前置状态: _buckets_array[index] 指向一个链表 LinkA
    // 后置状态: 创建一个 node，并包含指向链表 LinkA 的指针，于是共同组成一个新的链表 LinkB;
    //         _buckets_array[index] 指向新链表 LinkB
    _buckets_array[index] = new node(value, _buckets_array[index]);

    // 增加元素个数
    ++_size;

    // 返回新创建的元素
    return {&(_buckets_array[index]->value), true};
}

template <typename K, typename M, typename H>
M& HashMap<K, M, H>::at(const K& key) {
    auto [prev, node_found] = find_node(key);
    if (node_found == nullptr) {
        throw std::out_of_range("HashMap<K, M, H>::at: key not found");
    }
    return node_found->value.second;
}

template <typename K, typename M, typename H>
typename HashMap<K, M, H>::node_pair HashMap<K, M, H>::find_node(const K& key) const {
    size_t index = _hash_function(key) % bucket_count();
    auto curr = _buckets_array[index];
    node* prev = nullptr;  // if first node is the key, return {nullptr, front}
    while (curr != nullptr) {
        const auto& [found_key, found_mapped] = curr->value;
        if (found_key == key)
            return {prev, curr};
        prev = curr;
        curr = curr->next;
    }
    return {nullptr, nullptr};  // key not found at all.
}

template <typename K, typename M, typename H>
void HashMap<K, M, H>::debug() const {
    // Prints helpful debugging info using stream manipulators
    // so the formatting looks nice. Change it however you'd like.
    std::cout << std::setw(30) << std::setfill('-') << '\n'
              << std::setfill(' ') << "Printing debug information for your HashMap implementation\n"
              << "Size: " << size() << std::setw(15) << std::right << "Buckets: " << bucket_count()
              << std::setw(20) << std::right << "(load factor: " << std::setprecision(2)
              << load_factor() << ") \n\n";

    // Go through each bucket, and traverse through the linked list printing each element.
    for (size_t i = 0; i < bucket_count(); ++i) {
        std::cout << "[" << std::setw(3) << i << "]:";
        auto curr = _buckets_array[i];
        while (curr != nullptr) {
            const auto& [key, mapped] = curr->value;
            // next line will not compile if << not supported for K or M
            std::cout << " -> " << key << ":" << mapped;
            curr = curr->next;
        }
        std::cout << " /" << '\n';
    }
    std::cout << std::setw(30) << std::setfill('-') << '\n';
}

template <typename K, typename M, typename H>
bool HashMap<K, M, H>::erase(const K& key) {
    auto [prev, node_to_erase] = find_node(key);
    if (node_to_erase == nullptr) {
        return false;
    } else {
        size_t index = _hash_function(key) % bucket_count();
        // 头节点: 操作 _buckets_array[index]
        // 非头节点: 操作 prev->next
        (prev ? prev->next : _buckets_array[index]) = node_to_erase->next;
        delete node_to_erase;
        --_size;
        return true;
    }
}

/* Milestone 1: rehash */
template <typename K, typename M, typename H>
void HashMap<K, M, H>::rehash(size_t new_bucket_count) {
    if (new_bucket_count == 0) {
        throw std::out_of_range("HashMap<K, M, H>::rehash: new_bucket_count must be positive.");
    }
    std::vector<node*> new_buckets_array(new_bucket_count, nullptr);
    // TODO: 实现迭代器后，可以简化实现
    // 遍历当前的桶数组向量，向量的每个元素都是链表的头
    size_t cur_size = bucket_count();
    for (size_t index = 0; index < cur_size; index++) {
        // 遍历链表的每个节点
        while (_buckets_array[index] != nullptr) {
            // 取出头节点，并调整链表用于下一次循环
            auto node_to_rehash = _buckets_array[index];
            _buckets_array[index] = node_to_rehash->next;
            // 重新计算节点的哈希值
            const auto& [key, mapped] = node_to_rehash->value;
            size_t index = _hash_function(key) % new_bucket_count;
            // 插入节点到新的桶数组向量中（头插法）
            node_to_rehash->next = new_buckets_array[index];
            new_buckets_array[index] = node_to_rehash;
        }
    }
    // 用新的向量替换原向量
    _buckets_array = new_buckets_array;
}

/* Milestone 2: operator[] */
template <typename K, typename M, typename H>
M& HashMap<K, M, H>::operator[](const K& key) {
    auto [prev, node_found] = find_node(key);
    if (node_found == nullptr) {
        std::pair<value_type*, bool> ret = insert({key, M()});
        return ret.first->second;
    }
    return node_found->value.second;
}

template <typename K, typename M, typename H>
M& HashMap<K, M, H>::operator[](K&& key) {
    auto [prev, node_found] = find_node(key);
    if (node_found == nullptr) {
        std::pair<value_type*, bool> ret = insert({key, M()});
        return ret.first->second;
    }
    return node_found->value.second;
}

/* Milestone 2: operator<< */
template <typename K, typename M, typename H>
std::ostream& operator<<(std::ostream& os, const HashMap<K, M, H>& map) {
    os << "{";
    bool first = true;
    // TODO: 实现迭代器后，可以简化实现
    for (const auto& list : map._buckets_array) {  // friend 允许访问 private 成员
        auto node_to_output = list;
        while (node_to_output != nullptr) {
            auto [key, value] = node_to_output->value;
            if (first) {
                os << key << ":" << value;
                first = false;
            } else {
                os << ", " << key << ":" << value;
            }

            node_to_output = node_to_output->next;
        }
    }
    return os << "}";
}

/* Milestone 2: operator== */
template <typename K, typename M, typename H>
bool operator==(const HashMap<K, M, H>& lhs, const HashMap<K, M, H>& rhs) {
    // size 是否相等
    if (lhs.size() != rhs.size()) {
        return false;
    }
    // TODO: 实现迭代器后，可以简化实现
    for (const auto& list : lhs._buckets_array) {
        auto node_to_cmp = list;
        while (node_to_cmp != nullptr) {
            auto [key, value] = node_to_cmp->value;
            node_to_cmp = node_to_cmp->next;
            // key 是否存在；value 是否相等
            auto [prev, node_found] = rhs.find_node(key);
            if (node_found == nullptr) {
                return false;
            }
            auto [rkey, rvalue] = node_found->value;
            if (value != rvalue) {
                return false;
            }
        }
    }
    return true;
}

/* Milestone 2: operator!= */
template <typename K, typename M, typename H>
bool operator!=(const HashMap<K, M, H>& lhs, const HashMap<K, M, H>& rhs) {
    return !(lhs == rhs);
}

/* Milestone 2: const-correctness */
template <typename K, typename M, typename H>
const M& HashMap<K, M, H>::at(const K& key) const {
    auto [prev, node_found] = find_node(key);
    if (node_found == nullptr) {
        throw std::out_of_range("HashMap<K, M, H>::at: key not found");
    }
    return node_found->value.second;
}

/* Milestone 3: copy constructor */
template <typename K, typename M, typename H>
HashMap<K, M, H>::HashMap(const HashMap<K, M, H>& other)
    : HashMap{other.bucket_count(), other._hash_function} {
    // TODO: 实现迭代器后，可以简化实现
    for (const auto& list : other._buckets_array) {
        auto node_to_insert = list;
        while (node_to_insert != nullptr) {
            insert(node_to_insert->value);
            node_to_insert = node_to_insert->next;
        }
    }
}

/* Milestone 3: copy assignment */
template <typename K, typename M, typename H>
void HashMap<K, M, H>::swap(HashMap<K, M, H>& other) noexcept {
	using std::swap;
    swap(_size, other._size);
    swap(_hash_function, other._hash_function);
    swap(_buckets_array, other._buckets_array);
}

template <typename K, typename M, typename H>
HashMap<K, M, H>& HashMap<K, M, H>::operator=(const HashMap<K, M, H>& other) {
    auto temp{other};  // copy ctor
    swap(temp);
    return *this;
}

/* Milestone 3: move constructor */
template <typename K, typename M, typename H>
HashMap<K, M, H>::HashMap(HashMap&& other) {
    swap(other);
}

/* Milestone 3: move assignment */
template <typename K, typename M, typename H>
HashMap<K, M, H>& HashMap<K, M, H>::operator=(HashMap<K, M, H>&& other) noexcept {
    swap(other);
    return *this;
}
