/**
 * 文件: test_settings.h
 * ---------------------
 * 测试配置 - 切换宏定义为 1 或 0，开启或关闭对应测试
 */

// 1A-B - 重新哈希 rehash
#define RUN_TEST_1A 1
#define RUN_TEST_1B 1

// 2A - 索引运算符 operator[]
#define RUN_TEST_2A 1

// 2B - 插入运算符 operator<<
#define RUN_TEST_2B 1

// 2C - 关系运算符 operators== 和 operators!=
#define RUN_TEST_2C 1

// 2D - 常量正确性 const correctness (编译报错即表明未实现常量正确)
#define RUN_TEST_2D 1

// 3A - 拷贝语义 copy semantics
#define RUN_TEST_3A 1

// 3B - 移动语义 move semantics (正确性测试，只实现拷贝可以通过)
#define RUN_TEST_3B 1

// 3C - 移动语义 move semantics (效率测试，只实现拷贝无法通过)
#define RUN_TEST_3C 1

// 5A - 列表初始化构造函数 initializer_list constructor
#define RUN_TEST_5A 0

// 若未实现迭代器，下列测试将无法编译，这部分对技巧性要求较高

// 6A-D - 迭代器 HashMapIterator
#define RUN_TEST_6A 0
#define RUN_TEST_6B 0
#define RUN_TEST_6C 0
#define RUN_TEST_6D 0

// 6E-F - 迭代器常量正确性 const-correctness
#define RUN_TEST_6E 0
#define RUN_TEST_6F 0

// 5B - 范围构造函数 range constructor
#define RUN_TEST_5B 0
