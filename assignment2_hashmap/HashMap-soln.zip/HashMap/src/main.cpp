/**
 * 文件: main.cpp
 * --------------
 * 交互主程序，可以编写一些自定义的测试。
 *
 * @version 2023/05/20
 * @author xuehao （cs101.stickmind.com）
 * - 迁移到 CMake 构建工具
 * - 增加用户交互界面，方便编写一些自定义的测试
 * - 增加控制台颜色，改善辨识度
 *
 * @version 2020/05/20
 * @author Avery Wang (awvry952@stanford.edu)
 */

#include "hashmap.h"
#include "test_settings.h"
using namespace std;

/** 函数声明 */
extern int run_test_harness();
extern int userChoiceFromMenu(vector<string>& groups);

/* 自定义哈希函数 hashCoce */
template <typename T>
class hashCode {
public:
    size_t operator()(const T& key) const {
        size_t bytes = sizeof(key);
        size_t sum = 0;
        for (size_t i = 0; i < bytes; ++i) {
            unsigned char b = *(reinterpret_cast<const unsigned char*>(&key) + i);
            sum += b;
        }
        return sum;
    }
};

template <>
class hashCode<std::string> {
public:
    size_t operator()(const std::string& key) const {
        size_t sum = 0;
        for (auto c : key) {
            sum += static_cast<unsigned char>(c);
        }
        return sum;
    }
};

/** 可以在这个函数里编写一些自己的测试，通过交互界面选择执行 */
int student_main() {
    cout << "You're making an incredible progress!" << endl;

    HashMap<string, int> map;
    map.insert({"Anna", 2});
    map.insert({"Avery", 3});
    map.debug();

#ifdef RUN_TEST_1A  // Milestone 1: rehash
    map.rehash(3);
    map.debug();
#endif

#ifdef RUN_TEST_2A  // Milestone 2: operator[]
    // 未发现，则插入
    map["StickMind"];
    map.debug();
    // const HashMap<string, int> kMap;
    // kMap["StickMind"];
    string name = "Jack";
    map[name];
    map.debug();
#endif

#ifdef RUN_TEST_2B  // Milestone 2: operator<<
    cout << map << map << endl;
#endif

#ifdef RUN_TEST_2C  // Milestone 2: operator==/operator!=
    HashMap<string, int> lhs, rhs;
    if (lhs == rhs)
        cout << "lhs == rhs" << endl;
    rhs["StickMind"];
    if (lhs != rhs)
        cout << "lhs != rhs" << endl;
#endif

#ifdef RUN_TEST_2D  // Milestone 2: const-correctness
    const HashMap<string, int> kMap;
    // kMap.at("StickMind");
#endif

#ifdef RUN_TEST_3A  // Milestone 3: copy semantics
    const vector<pair<string, int>> vec{{"A", 3}, {"B", 2}, {"C", 1}, {"A", -5},
                                        {"B", 3}, {"A", 5}, {"C", 1}};
    hashCode<std::string> myHash;
    HashMap<std::string, int, hashCode<std::string>> map2(12, myHash);
    for (const auto& kv_pair : vec) {
        map2.insert(kv_pair);
    }
    HashMap<std::string, int, hashCode<std::string>> copy_constructed2{map2};
    HashMap<std::string, int, hashCode<std::string>> copy_assigned2;
    copy_assigned2 = map2;
    if (map2 == copy_constructed2)
        cout << "map2 == copy_constructed2" << endl;
    if (map2 == copy_assigned2)
        cout << "map2 == copy_assigned2" << endl;

    HashMap<string, int> jack;
    HashMap<string, int> mike;
    jack.insert({"$100", 3});
    mike.insert({"$50", 2});
    std::swap(jack, mike);
    cout << "Jack: " << jack << endl;
    cout << "Mike: " << mike << endl;
    jack.insert({"$100", 1});
    std::swap(jack, mike);
    cout << "Jack: " << jack << endl;
    cout << "Mike: " << mike << endl;
#endif

    auto hash_func = [](const int& key) {return key % 10; };
    HashMap<int, int, decltype(hash_func)> test(10, hash_func);

    return 0;
}

/** 主程序 */
int main() {
    cout << "This project is compoiled under C++ " << __cplusplus << "." << endl;
    vector<string> groups{"Student Main Test", "Run Test Harness"};
    return userChoiceFromMenu(groups) ? run_test_harness() : student_main();
}
