/**
 * 文件: utils.cpp
 * ---------------
 * 实用工具提取自斯坦福 C++ 库
 */

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

int getInteger(std::string prompt) {
    int value;
    std::string line;
    while (true) {
        std::cout << prompt;
        getline(std::cin, line);
        std::istringstream stream(line);
        stream >> value;
        if (!stream.fail() && stream.eof())
            break;
        std::cout << "Illegal integer format. Try again." << std::endl;
        if (prompt == "")
            prompt = "Enter an integer: ";
    }
    return value;
}

int getIntegerBetween(const std::string& prompt, int min, int max) {
    int value = 0;
    while (true) {
        value = getInteger(prompt);
        if (value < min || value > max) {
            std::cout.flush();
            std::cerr << "Please type a value between " << min << " and " << max << "."
                      << std::endl;
            std::cerr.flush();
        } else {
            break;
        }
    }
    return value;
}

int userChoiceFromMenu(vector<string>& options) {
    cout << endl;
    cout << "Tests are grouped by filename or by type." << endl;
    cout << "Select the test groups you wish to run:" << endl;
    cout << "----------------------------------------" << endl;
    int i = 0;
    for (const auto& entry : options) {
        cout << "  " << i++ << ") " << entry << endl;
    }
    int chosen = getIntegerBetween("Enter your selection: ", 0, options.size() - 1);
    if (chosen == 0) {
        cout << "No tests selected." << endl << endl;
    }
    return chosen;
}
