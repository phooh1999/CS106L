/**
 * 文件: main.cpp
 * --------------
 * 交互主程序，可以编写一些自定义的测试。
 *
 * @version 2023/05/20
 * @author xuehao （cs101.stickmind.com）
 * - 迁移到 CMake 构建工具
 * - 增加用户交互界面，方便编写一些自定义的测试
 * - 增加控制台颜色，改善辨识度
 *
 * @version 2020/05/20
 * @author Avery Wang (awvry952@stanford.edu)
 */

#include "hashmap.h"
#include "test_settings.h"
using namespace std;

/** 函数声明 */
extern int run_test_harness();
extern int userChoiceFromMenu(vector<string>& groups);

/** 可以在这个函数里编写一些自己的测试，通过交互界面选择执行 */
int student_main() {
    cout << "You're making an incredible progress!" << endl;

    HashMap<std::string, int> map;
    map.insert({"Anna", 2});

    cout << map << endl;
    return 0;
}

/** 主程序 */
int main() {
    cout << "This project is compoiled under C++ " << __cplusplus << "." << endl;
    vector<string> groups{"Student Main Test", "Run Test Harness"};
    return userChoiceFromMenu(groups) ? run_test_harness() : student_main();
}
