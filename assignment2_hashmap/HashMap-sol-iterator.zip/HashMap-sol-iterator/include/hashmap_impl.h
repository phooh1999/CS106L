/**
 * 文件: hashmap_impl.h
 * ---------------------
 * HashMap 实现部分
 */

#pragma once

#include <iomanip>  // for setw, setprecision, setfill, right
#include <sstream>  // for istringstream
#include "hashmap.h"

/*
 * Notes: in the member initializer list (see the next function for an
 * explanation), we call another constructor. This is called a delegating constructor.
 * We simply call the second constructor below with default parameters.
 *
 * Notes: here we use a delegating constructor. Here, we simply
 * call the second constructor below, passing in a default bucket_count of 10.
 */
template <typename K, typename M, typename H>
HashMap<K, M, H>::HashMap() : HashMap{kDefaultBuckets} {
}

/*
 * Notes: here we use a member initializer list to construct each of
 * our members. Recall that a member initializer list is superior to
 * assigning each member. Member initializer lists directly construct
 * a member, while assigning results in a default construction of a member
 * followed by reassignment. In fact, some types (references, uncopyable types)
 * cannot be reassigned, so member initializer lists are necessary. The type of
 * H here is likely a lambda function, which you've seen is non-copyable, so
 * the code won't compile if you use direct assignment.
 */
template <typename K, typename M, typename H>
HashMap<K, M, H>::HashMap(size_t bucket_count, const H& hash)
    : _size{0}, _hash_function{hash}, _buckets_array{bucket_count, nullptr} {
}

/*
 * Notes: The clear() call frees all the nodes. When the destructor
 * calls free, it will later free the memory for the vector, so we
 * don't have to worry about that here.
 */
template <typename K, typename M, typename H>
HashMap<K, M, H>::~HashMap() {
    clear();
}

/*
 * Notes: what is inline? inline is a non-binding directive to the
 * compiler to prefer inline substitution (copy the body of the function
 * to the location of the function call), rather than actually make
 * a function call. This is faster, particularly if the code is very short.
 */
template <typename K, typename M, typename H>
inline size_t HashMap<K, M, H>::size() const noexcept {
    return _size;
}

/*
 * Notes: prefer calling external member functions (size()) rather than
 * calling private functions or members whenever possible. This ensures
 * self-consistency between empty() and size().
 */
template <typename K, typename M, typename H>
inline bool HashMap<K, M, H>::empty() const noexcept {
    return size() == 0;
}

template <typename K, typename M, typename H>
inline float HashMap<K, M, H>::load_factor() const noexcept {
    return static_cast<float>(size()) / bucket_count();
};

template <typename K, typename M, typename H>
inline size_t HashMap<K, M, H>::bucket_count() const noexcept {
    return _buckets_array.size();
};

template <typename K, typename M, typename H>
bool HashMap<K, M, H>::contains(const K& key) const noexcept {
    return find_node(key).second != nullptr;
}

/*
 * Implementation details: loops through each bucket,
 * and repeatedly deletes curr and sets curr to the next node.
 * At the end curr (reference to the pointer living inside the vector)
 * will be nullptr.
 *
 * HashMap is still valid after clear and can be reused, because
 * the vector is still full of nullptrs.
 */
template <typename K, typename M, typename H>
void HashMap<K, M, H>::clear() noexcept {
    for (auto& curr : _buckets_array) {
        while (curr != nullptr) {
            auto trash = curr;
            curr = curr->next;
            delete trash;
        }
    }
    _size = 0;
}

/**
 * 此处返回类型包含指针，编译器无法判断其类型。
 * 所以，需要结合限定名和模板，并使用 typename 声明。
 * - “限定名”就是在 :: 运算符左边的名字
 * - 模板提供类型定义
 */
template <typename K, typename M, typename H>
std::pair<typename HashMap<K, M, H>::value_type*, bool> HashMap<K, M, H>::insert(
    const value_type& value) {
    const auto& [key, mapped] = value;           // 使用引用，避免数据拷贝
    auto [prev, node_to_edit] = find_node(key);  // 无需引用，指针拷贝影响不大

    // 如果元素存在，则无需操作，直接返回找到的当前元素
    if (node_to_edit != nullptr)
        return {&(node_to_edit->value), false};

    // 哈希值取模，以确定桶数组的索引
    size_t index = _hash_function(key) % bucket_count();

    // 前置状态: _buckets_array[index] 指向一个链表 LinkA
    // 后置状态: 创建一个 node，并包含指向链表 LinkA 的指针，于是共同组成一个新的链表 LinkB;
    //         _buckets_array[index] 指向新链表 LinkB
    _buckets_array[index] = new node(value, _buckets_array[index]);

    // 增加元素个数
    ++_size;

    // 返回新创建的元素
    return {&(_buckets_array[index]->value), true};
}

template <typename K, typename M, typename H>
M& HashMap<K, M, H>::at(const K& key) const {
    auto [prev, node_found] = find_node(key);
    if (node_found == nullptr) {
        throw std::out_of_range("HashMap<K, M, H>::at: key not found");
    }
    return node_found->value.second;
}

template <typename K, typename M, typename H>
typename HashMap<K, M, H>::node_pair HashMap<K, M, H>::find_node(const K& key) const {
    size_t index = _hash_function(key) % bucket_count();
    auto curr = _buckets_array[index];
    node* prev = nullptr;  // if first node is the key, return {nullptr, front}
    while (curr != nullptr) {
        const auto& [found_key, found_mapped] = curr->value;
        if (found_key == key)
            return {prev, curr};
        prev = curr;
        curr = curr->next;
    }
    return {nullptr, nullptr};  // key not found at all.
}

template <typename K, typename M, typename H>
void HashMap<K, M, H>::debug() const {
    // Prints helpful debugging info using stream manipulators
    // so the formatting looks nice. Change it however you'd like.
    std::cout << std::setw(30) << std::setfill('-') << '\n'
              << std::setfill(' ') << "Printing debug information for your HashMap implementation\n"
              << "Size: " << size() << std::setw(15) << std::right << "Buckets: " << bucket_count()
              << std::setw(20) << std::right << "(load factor: " << std::setprecision(2)
              << load_factor() << ") \n\n";

    // Go through each bucket, and traverse through the linked list printing each element.
    for (size_t i = 0; i < bucket_count(); ++i) {
        std::cout << "[" << std::setw(3) << i << "]:";
        auto curr = _buckets_array[i];
        while (curr != nullptr) {
            const auto& [key, mapped] = curr->value;
            // next line will not compile if << not supported for K or M
            std::cout << " -> " << key << ":" << mapped;
            curr = curr->next;
        }
        std::cout << " /" << '\n';
    }
    std::cout << std::setw(30) << std::setfill('-') << '\n';
}

template <typename K, typename M, typename H>
bool HashMap<K, M, H>::erase(const K& key) {
    auto [prev, node_to_erase] = find_node(key);
    if (node_to_erase == nullptr) {
        return false;
    } else {
        size_t index = _hash_function(key) % bucket_count();
        // 头节点: 操作 _buckets_array[index]
        // 非头节点: 操作 prev->next
        (prev ? prev->next : _buckets_array[index]) = node_to_erase->next;
        delete node_to_erase;
        --_size;
        return true;
    }
}

/* Milestone 1: Rehash */

template <typename K, typename M, typename H>
void HashMap<K, M, H>::rehash(size_t new_bucket_count) {
    if (new_bucket_count == 0) {
        throw std::out_of_range("HashMap<K, M, H>::rehash: new_bucket_count must be positive.");
    }
    std::vector<node*> new_buckets_array(new_bucket_count, nullptr);
    for (size_t i = 0; i < bucket_count(); i++) {
        auto curNode = _buckets_array[i];
        while (curNode != nullptr) {
            const auto &[key, mapped] = curNode->value;
            size_t index = _hash_function(key) % new_bucket_count; // 1. compute new index
            auto temp = curNode->next;                             // 2. record the next node
            curNode->next = new_buckets_array[index];              // 3. insert this node at the head of
            new_buckets_array[index] = curNode;                    //    link
            curNode = temp;                                        // 4. move to next node
        }
    }
    _buckets_array = new_buckets_array;
}

/* Milestone 2.1: Operator Overloading */

// 2.1.1: Operator[] Overloading
template <typename K, typename M, typename H>
M& HashMap<K, M, H>::operator[](const K& key) {
    return insert({key,{}}).first->second;
}

// 2.1.2: Operator<< Overloading
template <typename K, typename M, typename H>
std::ostream &operator<<(std::ostream &os, const HashMap<K, M, H> &map) {
    os << "{";

    for (auto iter = map.begin(); iter != map.end(); ) {
        os << iter->first << ":" << iter->second;
        if (++iter != map.end())
            os << ", ";
    }

    os << "}";
    return os;
}

// 2.1.3: Operator== and Operator!= Overloading
template <typename K, typename M, typename H>
bool HashMap<K, M, H>::operator==(const HashMap<K, M, H> &map) const {
    return this->size() == map.size()
           && std::is_permutation(this->begin(), this->end(), map.begin(), map.end());
}

template <typename K, typename M, typename H>
bool HashMap<K, M, H>::operator!=(const HashMap<K, M, H> &map) const {
    return !operator==(map);
}

/* Milestone 2.2: Const-Correctness */
// 1. at() const
// 2. operator== const
// 3. operator!= const

/* Milestone 3: Special Member Functions and Move Semantics */

/**
 * copy constructor
 */
template <typename K, typename M, typename H>
HashMap<K, M, H>::HashMap(const HashMap<K, M, H> &other) : HashMap(other.bucket_count(), other._hash_function) {
    for (const auto &val : other) {
        this->insert(val);
    }
}

/**
 * copy semantics: use swap()
 */
template <typename K, typename M, typename H>
HashMap<K, M, H> &HashMap<K, M, H>::operator=(const HashMap<K, M, H> &other) {
    HashMap<K, M, H> temp{other};
    swap(temp);
    return *this;
}

/**
 * move constructor: use swap()
 */
template <typename K, typename M, typename H>
HashMap<K, M, H>::HashMap(HashMap<K, M, H> &&other) : HashMap() {
    swap(other);
}

/**
 * move semantics: use swap()
 */
template <typename K, typename M, typename H>
HashMap<K, M, H> &HashMap<K, M, H>::operator=(HashMap<K, M, H> &&other) {
    HashMap<K, M, H> temp = std::move(other);
    swap(temp);
    return *this;
}

/* Side Quest: swap function */

/**
 * member swap function
 */
/* Implimention of function swap()  */
template <typename K, typename M, typename H>
void HashMap<K, M, H>::swap(HashMap<K, M, H> &other) {
    using std::swap;
    swap(this->_buckets_array, other._buckets_array);
    swap(this->_hash_function, other._hash_function);
    swap(this->_size, other._size);
}

/**
 * global swap function
 */
template <typename K, typename M, typename H>
void swap(HashMap<K, M, H> &lhs, HashMap<K, M, H> &rhs) {
    lhs.swap(rhs);
}

/* Milestone 5: initializer_list constructor, range constructor */

/**
 * initializer_list constructor
 */
template <typename K, typename M, typename H>
HashMap<K, M, H>::HashMap(std::initializer_list<value_type> init, size_t bucket_count, const H &hash)
    : HashMap(bucket_count, hash) {
    for (auto &value : init) {
        this->insert(value);
    }
}

/**
 * range constructor
 */
template <typename K, typename M, typename H>
template <typename InputIt>
HashMap<K, M, H>::HashMap(InputIt first, InputIt last, size_t bucket_count, const H &hash)
    : HashMap(bucket_count, hash) {
    for (auto iter = first; iter != last; iter++) {
        this->insert(*iter);
    }
}

/* Milestone 6: HashMapIterator */
template <typename K, typename M, typename H>
size_t HashMap<K, M, H>::first_not_empty_bucket() const {
    for (size_t i = 0; i < bucket_count(); i++) {
        if (_buckets_array[i] != nullptr) {
            return i;
        }
    }
    return bucket_count();
}

template <typename K, typename M, typename H>
typename HashMap<K, M, H>::iterator HashMap<K, M, H>::begin() noexcept {
    size_t index = first_not_empty_bucket();
    if (index == bucket_count()) {
        return end();
    }
    return HashMap_iterator<HashMap>{this, index, _buckets_array[index]};
}

template <typename K, typename M, typename H>
typename HashMap<K, M, H>::iterator HashMap<K, M, H>::end() noexcept {
    return HashMap_iterator<HashMap>{this, bucket_count(), nullptr};
}

template <typename K, typename M, typename H>
typename HashMap<K, M, H>::const_iterator HashMap<K, M, H>::begin() const noexcept {
    return const_cast<HashMap*>(this)->begin();
}

template <typename K, typename M, typename H>
typename HashMap<K, M, H>::const_iterator HashMap<K, M, H>::end() const noexcept {
    return const_cast<HashMap*>(this)->end();
}
