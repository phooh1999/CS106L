/**
 * 文件: hashmap_iterator.h
 * ------------------------
 * Milestone 6: 为 HashMap 类实现迭代器（iterators）
 */

#pragma once

#include <iterator>

template <typename hashmap>
class const_HashMap_iterator {

public:
    using value_type = typename hashmap::value_type;
    using difference_type = std::ptrdiff_t;
    using iterator_category = std::forward_iterator_tag;
    using pointer = const value_type*;
    using reference = const value_type&;
    using iterator_type = const typename hashmap::node*;

    const_HashMap_iterator() = default;
    const_HashMap_iterator(hashmap* map, size_t index, typename hashmap::node* node);

    reference operator*() const;

    pointer operator->() const;

    const_HashMap_iterator &operator++();
    const_HashMap_iterator operator++(int);

    bool operator==(const const_HashMap_iterator &other) const;
    bool operator!=(const const_HashMap_iterator &other) const;

protected:
    friend hashmap;

    hashmap* m_map {nullptr};
    size_t m_index;
    iterator_type m_it;

    void increment();

};

template <typename hashmap>
const_HashMap_iterator<hashmap>::const_HashMap_iterator(hashmap* map, size_t index, typename hashmap::node* node)
    : m_map{map}, m_index{index}, m_it{node} {}

template <typename hashmap>
typename const_HashMap_iterator<hashmap>::reference const_HashMap_iterator<hashmap>::operator*() const {
    return m_it->value;
}

template <typename hashmap>
typename const_HashMap_iterator<hashmap>::pointer const_HashMap_iterator<hashmap>::operator->() const {
    return &(m_it->value);
}

template <typename hashmap>
const_HashMap_iterator<hashmap>& const_HashMap_iterator<hashmap>::operator++() {
    increment();
    return *this;
}

template <typename hashmap>
const_HashMap_iterator<hashmap> const_HashMap_iterator<hashmap>::operator++(int) {
    auto oldIt {*this};
    increment();
    return oldIt;
}

template <typename hashmap>
void const_HashMap_iterator<hashmap>::increment() {

    if (m_map == nullptr) {
        return;
    }

    m_it = m_it->next;

    if (m_it == nullptr) {
        for (++m_index; m_index < m_map->bucket_count(); ++m_index) {
            m_it = (m_map->_buckets_array)[m_index];

            if (m_it != nullptr) {
                return;
            }
        }
    }
}

template <typename hashmap>
bool const_HashMap_iterator<hashmap>::operator==(const const_HashMap_iterator &other) const {
    return (m_map == other.m_map && m_index == other.m_index && m_it == other.m_it);
}

template <typename hashmap>
bool const_HashMap_iterator<hashmap>::operator!=(const const_HashMap_iterator &other) const {
    return !(*this == other);
}

/* ************************************************************** */


template <typename hashmap>
class HashMap_iterator : public const_HashMap_iterator<hashmap> {

public:
    using value_type = typename hashmap::value_type;
    using difference_type = std::ptrdiff_t;
    using iterator_category = std::forward_iterator_tag;
    using pointer = value_type*;
    using reference = value_type&;
    using iterator_type = typename hashmap::node*;

    HashMap_iterator() = default;
    HashMap_iterator(hashmap* map, size_t index, typename hashmap::node* node);

    // 这里参考书 <professional c++> 里面没有加const，编译就会报错
    reference operator*() const;
    pointer operator->() const;

    HashMap_iterator &operator++();
    HashMap_iterator operator++(int);

};

template <typename hashmap>
HashMap_iterator<hashmap>::HashMap_iterator(hashmap* map, size_t index, typename hashmap::node* node)
    : const_HashMap_iterator<hashmap>(map, index, node) {}

template <typename hashmap>
typename HashMap_iterator<hashmap>::reference HashMap_iterator<hashmap>::operator*() const {
    return const_cast<reference>(this->m_it->value);
}

template <typename hashmap>
typename HashMap_iterator<hashmap>::pointer HashMap_iterator<hashmap>::operator->() const {
    return const_cast<pointer>(&(this->m_it->value));
}

template <typename hashmap>
HashMap_iterator<hashmap>& HashMap_iterator<hashmap>::operator++() {
    this->increment();
    return *this;
}

template <typename hashmap>
HashMap_iterator<hashmap> HashMap_iterator<hashmap>::operator++(int) {
    auto oldIt {*this};
    this->increment();
    return oldIt;
}
