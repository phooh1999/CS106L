/**
 * 文件: hashmap.h
 * ---------------
 * TODO: 尝试模仿示例注释的写法，补充完整头文件的注释
 */

#ifndef HASHMAP_H
#define HASHMAP_H

#include <initializer_list>
#include <iostream>  // for cout
#include <vector>    // for vector
#include "hashmap_iterator.h"

/**
 * HashMap 模板类
 *
 * K = 键值 key 的类型
 * M = 映射值 mapped_type 的类型
 * H = 哈希函数 hash function 的类型；若未提供，默认使用 std::hash<K>
 *
 * 映射值 M 在斯坦福 C++ 库中也称作 value，即 key/value 键值对。
 * 此处定义成 mapped_type 是为了避免和 value_type 混淆。
 *
 * 本例中 value_type 指代 std::pair<const K, M> 整体，是容器中元素的类型。
 * 所有的 STL 容器都有 value_type，所有的 STL 算法都有 value_type 的别名。
 * 为了统一，我们遵循这样的约定。
 *
 * 用法示例:
 *      HashMap<std::string, int>
 *      这里的  K = key = std::string,
 *              M = mapped = int,
 *              value_type = std::pair<const std::string, int>.
 *
 * 要求:
 *      - H 是函数类型，接收 K 类型的参数，并输出一个 size_t 的值
 *      - K 和 M 必须满足常规要求（可拷贝，有默认构造器，支持相等性比较）
 */
template <typename K, typename M, typename H = std::hash<K>>
class HashMap {

public:
    /**
     * 定义 std::pair<const K, M> 的别名为 value_type，区别于 mapped_type
     *
     * 用法示例:
     *      HashMap::value_type val = {3, "Avery"};
     *      map.insert(val);
     */
    using value_type = std::pair<const K, M>;

    /**
     * 默认构造器 Default constructor
     * 创建一个空的 map —— 使用默认的桶值和默认的哈希函数
     *
     * 用法示例:
     *      HashMap map;
     *      HashMap map{};
     *
     * 复杂度: O(B), B = 桶的数量
     */
    HashMap();

    /**
     * 带参数构造器 Constructor with parameters
     * 创建一个空的 map —— 使用指定的桶值和指定的哈希函数；
     * 如果没有提供哈希函数，默认使用 std::hash<K>
     *
     * 用法示例:
     *      HashMap(10) map;
     *      HashMap map(10, [](const K& key) {return key % 10; });
     *      HashMap map{10, [](const K& key) {return key % 10; }};
     *
     * 复杂度: O(B), B = 桶的数量
     *
     * 关键字 explicit
     * 防止隐式转换（implicit-conversion）和拷贝初始化（copy-initialization）
     * 例如，
     *      HashMap<int, int> map(1.0);  // double -> int 禁止隐式转换
     *      HashMap<int, int> map = 1;   // copy-initialization 无法编译
     */
    explicit HashMap(size_t bucket_count, const H& hash = H());

    /**
     * 析构函数 Destructor
     * 由 map 在作用域结尾隐式调用
     *
     * 复杂度: O(N), N = 元素个数
     */
    ~HashMap();

    /**
     * 统计 map 中元素（K/M pair）的数量
     *
     * 用法示例:
     *       if (map.size() < 3) { ... }
     *
     * 复杂度: O(1)
     *
     * 关键字 inline
     * 表示函数较短，可由编译器优化
     *
     * 关键字 noexcept
     * 可以保证这个函数不会抛出异常，从而允许编译器优化这个函数。
     * 如果这个函数抛出异常，则程序自动终止。
     */
    inline size_t size() const noexcept;

    /**
     * 检测 map 是否为空
     *
     * 用法示例:
     *      if (map.empty()) { ... }
     *
     * 复杂度: O(1)
     */
    inline bool empty() const noexcept;

    /**
     * 计算负载系数 load_factor，即 size/bucket_count 的值
     *
     * 用法示例:
     *      float load_factor = map.load_factor();
     *
     * 复杂度: O(1)
     *
     * 注意:
     * 当负载系数太高时，在这个较小实现中，不会自动更新哈希值。
     * 如果你愿意，可以尝试扩展，实现自动更新哈希值。
     */
    inline float load_factor() const noexcept;

    /**
     * 计算桶的数量
     *
     * 用法示例:
     *      size_t buckets = map.bucket_count();
     *
     * 复杂度: O(1)
     *
     * 注意:
     * 当负载系数太高时，在这个较小实现中，不会自动更新哈希值。
     * 如果你愿意，可以尝试扩展这个函数，实现自动更新哈希值。
     */
    inline size_t bucket_count() const noexcept;

    /**
     * 检测 map 是否包含给定的 key
     *
     * 用法示例:
     *      if (map.contains("Avery")) { map.at("Avery"); ... }
     *
     * 复杂度: 平均复杂度 O(1), 最坏复杂度 O(N), N = 元素数量
     *
     * 注意:
     * 对于标准库 std::map 容器
     * 在使用 map.count(key) 时，根据返回值 0 或 1 判定 key 是否存在；
     * 在 C++20 中，我们还可以使用 map.contains(key) 新接口。
     */
    bool contains(const K& key) const noexcept;

    /**
     * 移除 map 中所有元素
     *
     * 用法示例:
     *      map.clear();
     *
     * 复杂度: O(N), N = 元素数量
     *
     * 注意:
     * 移除所有元素并释放内存后，map 依然有效并且可以继续插入元素。
     * 这就相当于构造了一个没有元素的 map，但是桶的数量保持不变。
     */
    void clear() noexcept;

    /**
     * 如果 key 不存在，则向 map 中插入元素；若存在，无插入操作。
     *
     * 返回值:
     *      pair<value_type*, bool>
     *      value_type* - 指针指向 node 内部刚刚构造好的元素
     *      bool - 若成功插入 key，返回 true；若 key 存在，返回 false
     *
     * 注意:
     * 通常来说，返回指向内部节点的裸指针是个糟糕的设计。
     * 更好的设计是返回一个迭代器，这将在 Milestone 8 中完成。
     *
     * 用法示例:
     *      HashMap<int, std::string> map;
     *      map.insert({3, "Avery"});        // 插入 key = 3, value = "Avery"
     *      map.insert({3, "Anna"});         // key = 3 已存在，无插入操作
     *
     * 复杂度: 平均复杂度 O(1)
     */
    std::pair<value_type*, bool> insert(const value_type& value);

    /**
     * 根据指定的 key 删除元素；若不存在，则无操作。
     *
     * 返回值: 如果 key 存在且成功删除，返回 true；如果 key 不存在，返回 false
     *
     * 用法示例:
     *      map.erase(3);     // 假设 K = int，删除 key 为 3 的元素并返回 true
     *
     * 复杂度: 平均复杂度 O(1), 最差复杂度 O(N), N = 元素个数
     *
     * 注意:
     * 如果后续实现了迭代器，调用 erase 后需要调整迭代器位置，避免指向删除后的位置。
     */
    bool erase(const K& key);

    /**
     * 根据给定的 key 返回一个映射值（mapped value）的左值引用；
     * 如果元素不存在，抛出 std::out_of_range 异常。
     *
     * 用法示例:
     *      map.at(3) = "Avery";            // 假设 {3, "Avery"} 成功加入 map
     *      std::string s = map.at(3);      // 则 s = "Avery"
     *
     * 异常: 如果 key 不在 map 中，抛出 std::out_of_range 异常
     *
     * 复杂度: 平均复杂度 O(1), 最差复杂度 O(N), N = 元素个数
     *
     * 注意:
     * 回忆一下，操作符 operator[] 不会检查范围并抛出异常；
     * 相反，如果没有发现 key，则构造一个默认元素并插入到 map 中。
     */
    M& at(const K& key) const;

    /**
     * 向标准输出打印哈希表的内容、元素和桶的数量、负载系数。
     *
     * 用法示例:
     *      map.debug();
     *
     * 复杂度: O(N), N = 元素个数
     *
     * 注意:
     * 如果 K 或 M 不支持 std::ostream 的 operator<< 操作，该函数不会编译。
     * 如果链表的逻辑有错误，函数将崩溃，比如忘记将末尾元素指向 nullptr 指针。
     *
     * 小窍门:
     * 在测试案例中可以大量使用 map.debug() 以确定哪个操作有问题。
     */
    void debug() const;

    /* Milestone 1: rehash
     *
     * 注意：
     * 不可以使用 insert/new/delete 新建或删除节点，只能重用现有的节点。
     * 测试案例用到了随机时间，偶尔会失败一两次，不用担心。
     * HashMap 不支持自动更新哈希值，而标准库 unordered_map 可以自动更新。
     * 甚至 unordered_map.rehash(0) 也是允许的，并强制进行无条件更新哈希值。
     * 如果你愿意，可以扩展这个功能。
     */

    /**
     * 重新调整桶数组的大小并重新计算每个元素的哈希值。
     *
     * 参数：new_buckets 可以大于、小于或者等于原来的桶数，但是必须大于 0
     *
     * 用法示例:
     *      map.rehash(30)
     *
     * 异常: 如果 new_buckets = 0，则抛出 std::out_of_range 异常
     *
     * 复杂度: 平均复杂度 O(N), 最差复杂度 O(N^2), N = 元素个数
     */
    void rehash(size_t new_buckets);

    /* Milestone 2: 运算符重载和常量正确性
     *   - operator[]
     *   - operator<<
     *   - operator==
     *   - operator!=
     *   - const-correctness
     *
     * 注意：此时尚未实现迭代器，需要灵活处理
     */
    M &operator[](const K& key);

    template <typename K2, typename M2, typename H2>
    friend std::ostream &operator<<(std::ostream &os, const HashMap<K2, M2, H2> &map);

    bool operator==(const HashMap<K, M, H> &map) const;

    bool operator!=(const HashMap<K, M, H> &map) const;

    /* Milestone 3: 拷贝语义和移动语义
     *   - copy constructor
     *   - copy assignment
     *   - move constructor
     *   - move assignment
     */
    HashMap(const HashMap<K, M, H> &other);
    HashMap<K, M, H> &operator=(const HashMap<K, M, H> &other);
    HashMap(HashMap<K, M, H> &&other);
    HashMap<K, M, H> &operator=(HashMap<K, M, H> &&other);

    void swap(HashMap<K, M, H> &other);

    /* Milestone 5: 列表初始化构造器和范围构造器
     *   - initializer_list constructor
     *   - range constructor
     */
    HashMap(std::initializer_list<value_type> init, size_t bucket_count = kDefaultBuckets, const H& hash = H());

    template <typename InputIt>
    HashMap(InputIt first, InputIt last, size_t bucket_count = kDefaultBuckets, const H& hash = H());

    /* Milestone 6: 迭代器
     *   - HashMap Iterator
     */
    friend class const_HashMap_iterator<HashMap>;
    friend class HashMap_iterator<HashMap>;
    using const_iterator = const_HashMap_iterator<HashMap>;
    using iterator = HashMap_iterator<HashMap>;

    iterator begin() noexcept;
    iterator end() noexcept;
    const_iterator begin() const noexcept;
    const_iterator end() const noexcept;

private:
    /**
     * 结构体 node 表示链表中的一个节点。
     * 每个节点包括一个 value_type 元素和一个指向下一个节点的指针。
     *
     * 注意该结构体在 private 中定义，客户端无法直接操作该结构体。
     *
     * 用法示例:
     *      HashMap<K, M, H>::node n;
     *      n->value = {3, 4};
     *      n->next = nullptr;
     */
    struct node {
        value_type value;
        node* next;

        /**
         * 带默认值的构造函数，如果忘记提供 nullptr 也不会出错。
         *
         * 用法示例:
         *      node* new_node = node({key, mapped}, next_ptr);
         */
        node(const value_type& value = value_type(), node* next = nullptr)
            : value(value), next(next) {
        }
    };

    /**
     * 定义类型别名，方便在 find_node 中使用
     *
     * 用法示例:
     *      auto& [prev, curr] = node_pair{nullptr, new node()};
     */
    using node_pair = std::pair<typename HashMap::node*, typename HashMap::node*>;

    /**
     * 通过给定的 key 寻找节点 N，并返回一个 node_pair 包含 N 的父节点和 N 本身。
     * 如果节点不存在，返回 {nullptr, nullptr}
     * 如果节点是首节点，返回 {nullptr, node}
     *
     * 例如链表 front -> [A] -> [B] -> [C] -> /
     *         其中 A, B, C, D 都是指针
     *
     *      find_node(A_key) = {nullptr, A}
     *      find_node(B_key) = {A, B}
     *      find_node(C_key) = {B, C}
     *      find_node(D_key) = {nullptr, nullptr}
     *
     * 用法示例:
     *      auto& [prev, curr] = find_node(3);
     *      if (prev == nullptr) { ... }
     *
     * 复杂度: 平均复杂度 O(1), 最差复杂度 O(N), N = 元素个数
     *
     * 注意: 在删除节点之前，需要调整该节点的 next 指针，所以这个函数是必需的。
     */
    node_pair find_node(const K& key) const;

private:
    /**
     * 实例变量 _size 用于记录元素的个数，即 K/M pairs 的数量
     * 不要和桶的数量混淆。
     */
    size_t _size;

    /**
     * 实例变量 _hash_function 用于记录哈希函数
     * 通过将 key 转换成 size_t 以确定将元素插入到哪个桶里
     *
     * 注意：哈希值需要对桶的数量进行取模运算！
     *
     * 用法示例:
     *      K element = // something;
     *      size_t index = _hash_function(element) % _bucket_count;
     *
     */
    H _hash_function;

    /**
     * 用 std::vector 表示的桶数组
     * 每一个桶都是一个链表，并且数组中存放的是链表的头指针
     *
     * 用法示例:
     *      node* ptr = _buckets_array[index];       // 存储元素类型为 node* 的向量
     *      const auto& [key, mapped] = ptr->value;  // 每个 node 包含一个 value 即 K/M pair
     */
    std::vector<node*> _buckets_array;

    /**
     * 定义一个默认桶数量的常量，用于默认构造函数
     */
    static const size_t kDefaultBuckets = 10;

    /* Milestone 6: 迭代器
     *   - HashMap Iterator
     */
    size_t first_not_empty_bucket() const;
};

// 分离接口和实现：若改为 .cpp 后缀，不要包含到 CMake 项目中
#include "hashmap_impl.h"

#endif  // HASHMAP_H
